package com.erp.mapper;

import com.erp.pojo.Power;
import tk.mybatis.mapper.common.Mapper;

public interface PowerMapper extends Mapper<Power> {
}
