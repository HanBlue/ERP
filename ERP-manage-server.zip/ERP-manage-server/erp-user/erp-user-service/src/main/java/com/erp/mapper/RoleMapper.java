package com.erp.mapper;

import com.erp.pojo.Role;
import tk.mybatis.mapper.common.Mapper;

public interface RoleMapper extends Mapper<Role> {
}
