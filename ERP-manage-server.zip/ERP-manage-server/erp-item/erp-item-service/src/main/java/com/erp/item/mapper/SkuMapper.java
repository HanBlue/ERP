package com.erp.item.mapper;

import com.erp.item.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;

public interface SkuMapper extends Mapper<Sku> {
}
