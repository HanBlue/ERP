package com.erp.item.mapper;

import com.erp.item.pojo.Promotion;
import tk.mybatis.mapper.common.Mapper;

public interface PromotionMapper extends Mapper<Promotion> {

}
