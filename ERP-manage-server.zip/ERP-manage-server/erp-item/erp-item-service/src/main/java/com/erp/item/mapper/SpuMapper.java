package com.erp.item.mapper;

import com.erp.item.pojo.Spu;
import tk.mybatis.mapper.common.Mapper;

public interface SpuMapper extends Mapper<Spu> {
}
