package com.erp.item.mapper;

import com.erp.item.pojo.SpecGroup;
import tk.mybatis.mapper.common.Mapper;

public interface SpecGropMapper extends Mapper<SpecGroup> {
}
