package com.erp.item.mapper;

import com.erp.item.pojo.SpuDetail;
import tk.mybatis.mapper.common.Mapper;

public interface SpuDetailMapper extends Mapper<SpuDetail> {
}
