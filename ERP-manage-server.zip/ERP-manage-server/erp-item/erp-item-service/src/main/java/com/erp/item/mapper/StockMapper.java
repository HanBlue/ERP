package com.erp.item.mapper;

import com.erp.item.pojo.Stock;
import tk.mybatis.mapper.common.Mapper;

public interface StockMapper extends Mapper<Stock> {
}
