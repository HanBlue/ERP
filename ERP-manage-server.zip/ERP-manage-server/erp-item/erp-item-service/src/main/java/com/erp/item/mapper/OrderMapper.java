package com.erp.item.mapper;

import com.erp.item.pojo.Order;
import tk.mybatis.mapper.common.Mapper;

public interface OrderMapper extends Mapper<Order> {
}
